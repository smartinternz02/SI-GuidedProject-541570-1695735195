from flask import  Flask, url_for,redirect
app = Flask(__name__)

@app.route("/home")
def home():
    return "welcome"

@app.route("/hello")
def hello():
    return "hello World"

@app.route("/hy")
def hay():
    return "hy World"

@app.route("/user/<enter>")
def user(enter):
    if enter == "welcome":
        return redirect(url_for("home"))
    elif enter == "hello":
        return redirect(url_for("hello"))
    else: 
        return redirect(url_for("hy"))
      

if __name__ == "__main__":
    app.run(debug =True )
